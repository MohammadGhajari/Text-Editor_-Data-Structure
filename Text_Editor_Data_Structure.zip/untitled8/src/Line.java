public class Line {
    Line next, prev;
    String content;

    public Line(String s) {
        content = s;
    }

    public Line() {}
}
