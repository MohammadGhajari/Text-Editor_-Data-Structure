public class Stack1Node {
    Stack1Node next;
    String command;
    public Stack1Node(String s) {
        this.command = s;
    }

}
